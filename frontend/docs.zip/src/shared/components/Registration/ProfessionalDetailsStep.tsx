import React, { useState } from "react";
import { Button } from "@shared/components/ui/button";
import { SelectField } from "@shared/components/FormInputs/SelectField";
import { DUMMY } from "@shared/config/common";
import {
  FileUploadField,
  NumberField,
  RequiredMark,
  TextField,
} from "@shared/components/FormInputs";
import { SearchableSelect } from "@shared/components/FormInputs/SearchableSelect";
import { handleAlphabeticInput } from "@shared/lib/utils";

export const ProfessionalDetailsStep = ({
  form,
  dropdownOption,
  nextStep,
  prevStep,
  reset,
  existingCertificate,
}: any) => {
  const {
    control,
    register,
    watch,
    formState: { errors },
  } = form;
  const qualifications = Array.isArray(dropdownOption?.data?.qualifications)
    ? dropdownOption.data.qualifications
    : [];

  const departments = Array.isArray(dropdownOption?.data?.departments)
    ? dropdownOption.data.departments
    : [];

  const availableDays = Array.isArray(dropdownOption?.data?.availableDays)
    ? dropdownOption.data.availableDays
    : [];

  const shiftTimes = Array.isArray(dropdownOption?.data?.shiftTimes)
    ? dropdownOption.data.shiftTimes
    : [];

  return (
    <div className="p-4 sm:p-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        <SearchableSelect
          control={control}
          name="qualificationId"
          label="Qualification"
          options={qualifications}
          labelKey="qualification_name"
          valueKey="id"
          required
          placeholder="Select qualification"
        />

        <SearchableSelect
          control={control}
          name="departmentId"
          label="Department"
          options={departments}
          labelKey="department_name"
          valueKey="id"
          required
          placeholder="Select department"
        />

        <SelectField
          label="Available Days"
          name="availableDayId"
          control={control}
          options={availableDays}
          labelKey="available_day"
          valueKey="id"
          required
          placeholder="Select Availability"
        />

        <SelectField
          label="Preferred Shift Time"
          name="shiftTimeId"
          control={control}
          options={shiftTimes}
          labelKey="shifttime"
          valueKey="id"
          required
          placeholder="Select Shift"
        />

        <NumberField
          label="Total Experience (Years)"
          maxLength={3}
          allowDecimal
          register={register("experience")}
          placeholder="Enter your experience"
        />

        <TextField
          label="Samagam Held In"
          register={register("samagamHeldIn", {
            pattern: {
              value: /^[A-Za-z\s]+$/,
              message:
                "Samagam Held In should contain only alphabets and spaces (no numbers or symbols)",
            },
            onChange: (e: any) =>
              handleAlphabeticInput(e, "samagamHeldIn", form.setValue),
          })}
          placeholder="Enter samagam held in"
          error={errors.samagamHeldIn}
        />

        <TextField
          label="Sewa Performed During Last Samagam"
          register={register("lastSewa", {
            pattern: {
              value: /^[A-Za-z\s]+$/,
              message:
                "Last Sewa should contain only alphabets and spaces (no numbers or symbols)",
            },
            onChange: (e: any) =>
              handleAlphabeticInput(e, "lastSewa", form.setValue),
          })}
          placeholder="Enter last Sewa performed"
          error={errors.lastSewa}
        />

        <TextField
          label="Recommended By"
          register={register("recommendedBy", {
            pattern: {
              value: /^[A-Za-z\s]+$/,
              message:
                "Recommended By should contain only alphabets and spaces (no numbers or symbols)",
            },
            onChange: (e: any) =>
              handleAlphabeticInput(e, "recommendedBy", form.setValue),
          })}
          placeholder="Enter recommender's name"
          error={errors.recommendedBy}
        />

        <FileUploadField
          label="Upload Certificate"
          existingUrl={existingCertificate}
          accept=".jpg,.jpeg,.png,.pdf"
          required
          selectedFile={watch("certificate")}
          register={register("certificate", {
            validate: {
              fileType: (fileList) => {
                if (!fileList || (fileList instanceof FileList && fileList.length === 0)) {
                  if (existingCertificate) return true;
                  return "Please upload a certificate";
                }

                const allowedExtensions = [
                  "jpg",
                  "jpeg",
                  "png",
                  "pdf",
                ];
                const file = fileList[0];
                const ext = file.name.split(".").pop()?.toLowerCase();

                return (
                  allowedExtensions.includes(ext || "") ||
                  "File type not supported. Please upload an image (jpg, png, etc)"
                );
              },
              fileSize: (fileList) => {
                if (!fileList || fileList.length === 0) return true;
                const file = fileList[0];
                const MAX_SIZE = 2 * 1024 * 1024; // 5MB

                return (
                  file.size <= MAX_SIZE ||
                  `File size must be under 2MB (current size: ${(
                    file.size /
                    1024 /
                    1024
                  ).toFixed(2)}MB)`
                );
              },
            },
          })}
          error={errors.certificate}
        />
      </div>

      <div className="mt-8 flex flex-col sm:flex-row justify-between gap-4">
        <Button
          size="lg"
          className="bg-primary rounded-2xl font-bold text-white w-full sm:w-auto"
          onClick={prevStep}
        >
          Previous
        </Button>
        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <Button
            size="lg"
            type="button"
            className="bg-red-600 rounded-2xl font-bold text-white w-full sm:w-auto"
            onClick={reset}
          >
            Reset
          </Button>
          <Button
            size="lg"
            onClick={nextStep}
            className="bg-primary rounded-2xl font-bold text-white w-full sm:w-auto"
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
};
