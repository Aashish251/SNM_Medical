export { default } from "@features/admin/master-search";
