import { Header } from "@admin-panel/components/layout/header";
import { Main } from "@admin-panel/components/layout/main";
import { ProfileDropdown } from "@admin-panel/components/profile-dropdown";
import { Search } from "@admin-panel/components/search";
import { ThemeSwitch } from "@admin-panel/components/theme-switch";
import { useAdminTableSearch } from "@admin-panel/hooks/use-admin-table-search";
import { UsersDialogs } from "./components/users-dialogs";
import { UsersPrimaryButtons } from "./components/users-primary-buttons";
import { UsersProvider } from "./components/users-provider";
import { UsersTable } from "./components/users-table";
import { users } from "./data/users";

export function Users() {
  const { search, navigate } = useAdminTableSearch();

  return (
    <UsersProvider>
      <Header fixed>
        <Search className="me-auto" />
        <ThemeSwitch />
        <ProfileDropdown />
      </Header>

      <Main className="flex flex-1 flex-col gap-4 sm:gap-6">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">User List</h2>
            <p className="text-muted-foreground">
              Manage your users and their roles here.
            </p>
          </div>
          <UsersPrimaryButtons />
        </div>
        <UsersTable data={users} search={search} navigate={navigate} />
      </Main>

      <UsersDialogs />
    </UsersProvider>
  );
}
